--  ##########################################################################################################################
--  2.2.2 Utilize Hive to create tables in the Hadoop Filesystem and then load the data extracted via Sqoop into those tables. 
--        Data Engineers will be map to transform the data based on requirements found in the Mapping Document. 
--  ##########################################################################################################################

DROP TABLE CDW_SAPP_BRANCH;

CREATE TABLE CDW_SAPP_BRANCH (
  BRANCH_CODE int ,
  BRANCH_NAME varchar(25) ,
  BRANCH_STREET varchar(30) ,
  BRANCH_CITY varchar(30) ,
  BRANCH_STATE varchar(30) ,
  BRANCH_ZIP int  ,
  BRANCH_PHONE varchar(10)  )
  ROW FORMAT DELIMITED FIELDS TERMINATED BY ','  location '/user/maria_dev/CDW_SAPP2/';
  
  
DROP TABLE CDW_SAPP_CREDITCARD ;  
  
CREATE TABLE CDW_SAPP_CREDITCARD (
  TRANSACTION_ID int(9),
  DAY int,
  MONTH int ,
  YEAR int ,
  CREDIT_CARD_NO varchar(16) ,
  CUST_SSN int ,
  BRANCH_CODE int ,
  TRANSACTION_TYPE varchar(30) ,
  TRANSACTION_VALUE decimal(20,3) )
   ROW FORMAT DELIMITED FIELDS TERMINATED BY ','  location '/user/maria_dev/CDW_SAPCC/';

   
   
DROP  TABLE CDW_SAPP_CUSTOMER;

CREATE TABLE CDW_SAPP_CUSTOMER (
  FIRST_NAME varchar(40),
  MIDDLE_NAME varchar(40) ,
  LAST_NAME varchar(40) ,
  SSN int(9),
  CREDIT_CARD_NO varchar(16) ,
  APT_NO varchar(7) ,
  STREET_NAME varchar(30) ,
  CUST_CITY varchar(30),
  CUST_STATE varchar(30) ,
  CUST_COUNTRY varchar(30) ,
  CUST_ZIP varchar(7) ,
  CUST_PHONE int(10) ,
  CUST_EMAIL varchar(40) )
   ROW FORMAT DELIMITED FIELDS TERMINATED BY ','  location '/user/maria_dev/CDW_SAP3/';


   
DROP TABLE CDW_SAPP_TIME ;  
  
CREATE TABLE CDW_SAPP_TIME (
  TIMEID VARCHAR(10),
  DAY int,
  MONTH int ,
  QUARTR INT,
  YEAR int  )
   ROW FORMAT DELIMITED FIELDS TERMINATED BY ','  location '/user/maria_dev/CDW_SAPP4/';
   
 